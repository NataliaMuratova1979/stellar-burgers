export { ForgotPassword } from './forgot-password';
